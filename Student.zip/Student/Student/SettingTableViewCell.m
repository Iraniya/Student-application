//
//  SettingTableViewCell.m
//  Student
//
//  Created by agile on 05/07/16.
//  Copyright (c) 2016 iraniya. All rights reserved.
//

#import "SettingTableViewCell.h"

@implementation SettingTableViewCell
@synthesize settingButton;
- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
