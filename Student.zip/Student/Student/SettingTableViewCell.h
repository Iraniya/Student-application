//
//  SettingTableViewCell.h
//  Student
//
//  Created by agile on 05/07/16.
//  Copyright (c) 2016 iraniya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingTableViewCell : UITableViewCell
{
}
@property(nonatomic,strong) IBOutlet UIButton *settingButton;
@end
