//
//  NSDictionary+Utility.m
//  Student
//
//  Created by agilepc-140 on 06/07/16.
//  Copyright (c) 2016 iraniya. All rights reserved.
//

#import "NSDictionary+Utility.h"

@implementation NSDictionary (Utility)

@end
