//
//  HomeTableViewCell.m
//  Student
//
//  Created by agilepc-140 on 29/06/16.
//  Copyright (c) 2016 iraniya. All rights reserved.
//

#import "HomeTableViewCell.h"

@implementation HomeTableViewCell

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
