//
//  AddSemesterViewController.m
//  Student
//
//  Created by agile on 02/07/16.
//  Copyright (c) 2016 iraniya. All rights reserved.
//

#import "AddSemesterViewController.h"
#import "enterSemesterDetailsViewController.h"

@interface AddSemesterViewController ()

@end

@implementation AddSemesterViewController

@synthesize SemesterDetailTextField,numOfSubjectTextField;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    //allocate 
    studentEducationDetailsArray = [[NSMutableArray alloc]init];
    
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Submit Button

- (IBAction)enterSemesterBtn:(id)sender {
    
    studentSemesterDict = [[NSMutableDictionary alloc]init];
    [studentSemesterDict setObject:SemesterDetailTextField.text forKey:@"SemesterNumber"];
    [studentSemesterDict setObject:numOfSubjectTextField.text forKey:@"NumOfSubject"];
    
    [studentEducationDetailsArray addObject:studentSemesterDict];
    
    enterSemesterDetailsViewController *enterSemesterDetailsViewControllerObject = [[enterSemesterDetailsViewController alloc]initWithNibName:@"enterSemesterDetailsViewController" bundle:nil];

    [self.navigationController pushViewController:enterSemesterDetailsViewControllerObject animated:YES];
}


-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:true];
}
@end
