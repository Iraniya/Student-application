//
//  HomeTableViewCell.h
//  Student
//
//  Created by agilepc-140 on 29/06/16.
//  Copyright (c) 2016 iraniya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeTableViewCell : UITableViewCell
{
    
}
@property(nonatomic,strong) IBOutlet UILabel *semLableObject;
@property(nonatomic,strong) IBOutlet UILabel *semDetailsLableObject;
@end
