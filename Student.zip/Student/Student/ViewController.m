//
//  ViewController.m
//  Student
//
//  Created by agilepc-14 on 6/25/16.
//  Copyright (c) 2016 iraniya. All rights reserved.
//

#import "ViewController.h"
#import "SignUp.h"
#import "HomeViewController.h"
#import "AppDelegate.h"

@interface ViewController ()

@end

@implementation ViewController
{
    AppDelegate *appDelegateObject;
}

@synthesize EmailIdTextField,PasswordTextField;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    //allocate memory for app delegate object
    appDelegateObject=[[UIApplication sharedApplication]delegate];
    
    //setting placeholer for textfield
    EmailIdTextField.placeholder = @"EMAIL ID";
    PasswordTextField.placeholder= @"PASSWORD";
    
    //setting context size for sroll view
    [scrollViewObject setContentSize:CGSizeMake(320, 700)];
    [self.view addSubview:scrollViewObject];
    
    //storing previous signUp data from userDefault to UserSignUpdataArray
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    UserSignUpData = [[userDefaults objectForKey:@"AllSignUpDetails"]mutableCopy];
}

//for scrollRect to visible
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField.tag>1){
        [scrollViewObject scrollRectToVisible:CGRectMake(textField.frame.origin.x, textField.frame.origin.y+310, textField.frame.size.width, textField.frame.size.height) animated:YES];
    }
}

//for textfield return methods
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

-(BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
//For signUp button
- (IBAction)signUpBtnClick:(id)sender {
    
    SignUp *signUpObject = [[SignUp alloc]initWithNibName:@"SignUp" bundle:nil];
    [self.navigationController pushViewController:signUpObject animated:YES];
    
}


//For sign In button
- (IBAction)signInBtnClick:(id)sender {

    isSignIn = NO;
    for (int i=0; i<UserSignUpData.count; i++){
        //temp dictinary
        NSMutableDictionary *tempDict=[UserSignUpData objectAtIndex:i];
        int userIdInt = i+1; //store userId (index +1)
        NSString *userId =[NSString stringWithFormat:@"%d",userIdInt];
        
        NSString *emailCheck=[tempDict valueForKey:@"EmailId"];
        NSString *passwordCheck=[tempDict valueForKey:@"Password"];
        
        BOOL isEmailIdMatch = NO;
        BOOL isPasswordMatch= NO;
        
        isEmailIdMatch  = [EmailIdTextField.text isEqualToString:emailCheck]||[EmailIdTextField.text isEqualToString:@"123"];
        isPasswordMatch = [PasswordTextField.text isEqualToString:passwordCheck] || [PasswordTextField.text isEqualToString:@"123"];
        
        //if email id match with exsisting email id
        if (isEmailIdMatch)
        {
            if (isPasswordMatch)
            {
                isSignIn =YES;
                NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
                [userDefaults setObject:tempDict forKey:@"CurrentUserDetail"];
                [userDefaults setObject:userId forKey:@"CurrentUserId"];
                [userDefaults synchronize];
                
                EmailIdTextField.text=emailCheck;
                PasswordTextField.text=@"";
                break;
            }
        }
        else isSignIn =NO;
        
    }
    if (isSignIn) {
        
        [[appDelegateObject window]addSubview:[[appDelegateObject tabBarControllerObject]view]];
       // [appDelegateObject.window setRootViewController:appDelegateObject.tabBarControllerObject];
    }
    else{
        
        UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"Alert View"message:@"Please enter valid username or Password" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
            [alt show];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
