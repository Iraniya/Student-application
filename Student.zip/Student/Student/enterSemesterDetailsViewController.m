//
//  enterSemesterDetailsViewController.m
//  Student
//
//  Created by agile on 02/07/16.
//  Copyright (c) 2016 iraniya. All rights reserved.
//

#import "enterSemesterDetailsViewController.h"

@interface enterSemesterDetailsViewController ()

@end

@implementation enterSemesterDetailsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [scrollViewObject setContentSize:CGSizeMake(320, 1000)];
    
    [self SettingView];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



//=====setting scroll view ==========////

//copy Past :-p 

-(void)SettingView
{
    int count = 10;
    
    int xPos=40,yPos=100,height=40,width=100;
    for (int i=1; i<=count; i++)
    {
        SubjectTextField=[[UITextField alloc]initWithFrame:CGRectMake(xPos, yPos, width, height)];
        SubjectTextField.placeholder=[NSString stringWithFormat:@"Subject%d",i];
        
        SubjectTextField.delegate=self;
        [scrollViewObject addSubview:SubjectTextField];
        xPos=xPos+width+20;
        
        MarksTextField=[[UITextField alloc]initWithFrame:CGRectMake(xPos, yPos, width, height)];
        MarksTextField.placeholder=[NSString stringWithFormat:@"Marks%d",i];
        MarksTextField.delegate=self;
        [scrollViewObject addSubview:MarksTextField];
        xPos=xPos+width+20;
        
        UILabel *outOfMarks=[[UILabel alloc]initWithFrame:CGRectMake(xPos, yPos, width, height)];
        [outOfMarks setText:@"/100"];
        [outOfMarks setTextColor:[UIColor whiteColor]];
        [scrollViewObject addSubview:outOfMarks];
        yPos=yPos+height+20;
        xPos=40;
    }
   /*
    UIButton *btnSubmit=[UIButton buttonWithType:UIButtonTypeCustom];
    [btnSubmit setFrame:CGRectMake(xPos+50, yPos, width, height)];
    [btnSubmit setTitle:btnName forState:UIControlStateNormal];
    [btnSubmit setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btnSubmit addTarget:self action:@selector(btnSubmitClick) forControlEvents:UIControlEventTouchUpInside];
    [scrollViewObject addSubview:btnSubmit];
    */
    }

@end
