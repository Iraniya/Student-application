//
//  NSFileManager+Utility.h
//  Student
//
//  Created by agilepc-140 on 06/07/16.
//  Copyright (c) 2016 iraniya. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSFileManager (Utility)
+(void)createFolderInDocumentDirectory:(NSString*)folderName;
@end
